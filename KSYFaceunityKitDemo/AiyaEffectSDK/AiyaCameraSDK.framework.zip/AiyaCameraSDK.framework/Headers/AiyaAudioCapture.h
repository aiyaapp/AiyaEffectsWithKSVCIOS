//
//  AiyaAudioCapture.h
//  AiyaCameraSDK
//
//  Created by 汪洋 on 2017/2/23.
//  Copyright © 2017年 深圳哎吖科技. All rights reserved.
//

#import "AYGPUImageMovieWriter.h"

@protocol AiyaAudioCaptureDelegate <NSObject>

/**
 音频数据的回调
 */
- (void)audioBuffer:(CMSampleBufferRef)audioBuffer;

@end

@interface AiyaAudioCapture : AYGPUImageMovieWriter

@property (nonatomic, weak) id<AiyaAudioCaptureDelegate> audioCaptureDelegate;

- (void)processAudioBuffer:(CMSampleBufferRef)audioBuffer;

@end
